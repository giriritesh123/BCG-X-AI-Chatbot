
GFC AI Chatbot - Task 2 Submission

This chatbot responds to predefined financial queries using data from 10-K reports for Microsoft, Apple, and Tesla (2020-2022).

How it works:
- Run chatbot.py using Python 3.x
- Ask questions like:
  > What is the total revenue?
  > What is the net income?
  > What are the total assets?
  > What is the cash flow from operations?
- The chatbot prompts for company name and year to return accurate results.

Limitations:
- Only handles predefined financial queries
- Works with the included CSV data only
- No NLP or learning capability

Files included:
- chatbot.py
- financials.csv
- README.txt
