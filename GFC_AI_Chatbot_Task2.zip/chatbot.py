
import pandas as pd

# Load financial data
df = pd.read_csv('financials.csv')

def get_financial_data(company, year, metric):
    result = df[(df['Company'].str.lower() == company.lower()) & (df['Year'] == int(year))]
    if result.empty:
        return f"Data not found for {company} in {year}."
    value = result.iloc[0][metric]
    return f"{metric} of {company} in {year} was {value} billion USD."

def chatbot():
    print("Welcome to GFC Financial Chatbot! Type 'exit' to quit.")
    while True:
        user_input = input("Ask a question: ").lower()
        if 'exit' in user_input:
            print("Goodbye!")
            break
        elif "total revenue" in user_input:
            company = input("Enter company name: ")
            year = input("Enter year: ")
            print(get_financial_data(company, year, 'Total Revenue'))
        elif "net income" in user_input:
            company = input("Enter company name: ")
            year = input("Enter year: ")
            print(get_financial_data(company, year, 'Net Income'))
        elif "total assets" in user_input:
            company = input("Enter company name: ")
            year = input("Enter year: ")
            print(get_financial_data(company, year, 'Total Assets'))
        elif "cash flow" in user_input:
            company = input("Enter company name: ")
            year = input("Enter year: ")
            print(get_financial_data(company, year, 'Cash Flow from Ops'))
        else:
            print("Sorry, I can only answer predefined questions about revenue, income, assets, and cash flow.")

if __name__ == "__main__":
    chatbot()
